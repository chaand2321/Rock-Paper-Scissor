// let playerScore=0;
// let compScore=0;

// let roundWinner='';


// let rock = document.getElementById("rock");
// let paper = document.getElementById("paper");
// let scissor = document.getElementById("scissor");
// let playerScoreDisplay = document.getElementById("p-score")
// let computerScoreDisplay = document.getElementById("c-score");
// let roundWinDisplay = document.getElementById("roundAns");
// let compChooseDisplay = document.getElementById("ansDiv");


// let playerSelection = '';

// //SELECTING PLAYER MODE
// rock.addEventListener('click' , ( )=>handlingValue('ROCK') );

// paper.addEventListener('click' , ( )=>handlingValue('PAPER'));
    
// scissor.addEventListener('click' , ( )=>handlingValue('SCISSOR'));
    


// function handlingValue(playerSelection){
//     // if (isGameOver()) {
//     //     openEndgameModal()
//     //     return
//     //   }
    
//       const computerSelection = getRandomChoice()
//       compChooseDisplay.textContent=computerSelection;
//       playRound(playerSelection, computerSelection)
      
//     //   updateScore()
    
//     //   if (isGameOver()) {
//     //     openEndgameModal()
//     //     setFinalMessage()
//     //   }
// }

// function isGameOver(){
//     return playerScore==5 || compScore==5;
// }

// //SELECTING COMPUTER MODE
// // let compSelection = getRandomChoice();

// function getRandomChoice(){
//     let randomNumber = Math.floor(Math.random()*3);
//     switch(randomNumber) {
//         case 0:
//             return 'ROCK';
//         case 1 :
//             return 'PAPER'
//         case 2 :
//             return 'SCISSOR';        
//     } 
// }

// //RESULT CHECKING
// function playRound( playerSelection , computerSelection){
//         // playerScoreDisplay.textContent=playerScore;
//         // computerScoreDisplay.textContent=compScore;
//     if(playerSelection === computerSelection){
//           roundWinner = "TIE";
//     }

//     if( 
//         (playerSelection === 'ROCK' && computerSelection === 'SCISSORS') ||
//     (playerSelection === 'SCISSORS' && computerSelection === 'PAPER') ||
//     (playerSelection === 'PAPER' && computerSelection === 'ROCK') 
//     ){
//         playerScore++;
//         roundWinner="PLAYER WON";
//     }

//     if(
//         (computerSelection === 'ROCK' && playerSelection === 'SCISSORS') ||
//     (computerSelection === 'SCISSORS' && playerSelection === 'PAPER') ||
//     (computerSelection === 'PAPER' && playerSelection === 'ROCK')
//     )
//     {
//         compScore++;
//         roundWinner="COMPUTER WON";
//     }

//     roundWinDisplay.textContent=roundWinner;
// }


let playerScore = 0;
let compScore = 0;

let roundWinner = '';

let rock = document.getElementById("rock");
let paper = document.getElementById("paper");
let scissor = document.getElementById("scissor");
let playerScoreDisplay = document.querySelector(".p-score h3"); // Updated this line
let computerScoreDisplay = document.querySelector(".c-score h3"); // Updated this line
let roundWinDisplay = document.querySelector(".roundAns");
let compChooseDisplay = document.querySelector(".ansDiv");

let playerSelection = '';

// SELECTING PLAYER MODE
rock.addEventListener('click', () =>{ console.log("Rock button clicked");
handlingValue('ROCK'); } );

paper.addEventListener('click', () => handlingValue('PAPER'));

scissor.addEventListener('click', () => handlingValue('SCISSOR'));

function handlingValue(playerSelection) {
    const computerSelection = getRandomChoice();
    compChooseDisplay.textContent = computerSelection;
    playRound(playerSelection, computerSelection);
    updateScore(); // Added this line to update the scores
}

function isGameOver() {
    return playerScore == 5 || compScore == 5;
}

// SELECTING COMPUTER MODE

function getRandomChoice() {
    let randomNumber = Math.floor(Math.random() * 3);
    switch (randomNumber) {
        case 0:
            return 'ROCK';
        case 1:
            return 'PAPER';
        case 2:
            return 'SCISSOR';
    }
}

// RESULT CHECKING
function playRound(playerSelection, computerSelection) {
    if (playerSelection === computerSelection) {
        roundWinner = "TIE";
    } else if (
        (playerSelection === 'ROCK' && computerSelection === 'SCISSOR') ||
        (playerSelection === 'SCISSOR' && computerSelection === 'PAPER') ||
        (playerSelection === 'PAPER' && computerSelection === 'ROCK')
    ) {
        playerScore++;
        roundWinner = "PLAYER WON";
    } else if (
        (computerSelection === 'ROCK' && playerSelection === 'SCISSOR') ||
        (computerSelection === 'SCISSOR' && playerSelection === 'PAPER') ||
        (computerSelection === 'PAPER' && playerSelection === 'ROCK')
    ) {
        compScore++;
        roundWinner = "COMPUTER WON";
    }

    roundWinDisplay.textContent = roundWinner;
}

function updateScore() {
    playerScoreDisplay.textContent = playerScore;
    computerScoreDisplay.textContent = compScore;
}




    


